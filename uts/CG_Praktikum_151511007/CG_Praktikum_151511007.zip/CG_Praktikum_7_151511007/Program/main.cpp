#include <stdio.h>
#include "library.h"
#include <time.h>
#include <Windows.h>

int main(int argc, char** argv) {
	initwindow(800, 800);
	
	int rhr = RCLOCK - 40, rmnt = RCLOCK - 20, rsc = RCLOCK;
	SYSTEMTIME systemtime;
	GetSystemTime(&systemtime);
	int dsc = (45+systemtime.wSecond) * 360 / 60;
	int dmnt = (45+systemtime.wMinute) * 360 / 60;
	int dhr = (systemtime.wHour+7) * 360 / 24;
	point pmid = initPoint(MIDPOINT, MIDPOINT);
	int tock = 0;
	while(true){
		tock++;
		printf("%d %d %d %d\n", tock, dsc, dmnt, dhr);
		drawcircle(pmid, RCLOCK, 9);
		drawline(pmid, initPoint(pmid.x + rsc * cos((M_PI / 180) * dsc), pmid.y + rsc * sin((M_PI / 180) * dsc)), 5);
		drawline(pmid, initPoint(pmid.x + rmnt * cos((M_PI / 180) * dmnt), pmid.y + rmnt * sin((M_PI / 180) * dmnt)), 3);
		drawline(pmid, initPoint(pmid.x + rhr * cos((M_PI / 180) * dhr), pmid.y + rhr * sin((M_PI / 180) * dhr)), 2);
		
		dsc = dsc + 6; 
		if(dsc % 270 == 0  && dsc >= 270){
			dmnt = dmnt + 6;
		}
		if(dsc % 360 == 0  && dsc >= 360){
			dsc = 0;
		}  
		if(dmnt % 270 == 0 && dmnt >= 270){
			dhr = dhr + 6;
		}
		if(dmnt % 360 == 0 && dmnt >= 360){
			dmnt = 0;
		}
		
		delay(DEFAULT_DELAY);
		cleardevice();
	}
	
	getch();
	return 0;
}
